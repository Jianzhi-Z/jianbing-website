# 煎饼个人网站 - 全栈版

AI行动家的个人品牌展示平台，包含完整的后台管理系统。

## 功能特性

### 前台展示
- 首页：个人简介、最新文章、产品展示
- 文章列表：分类筛选、分页
- 文章详情：Markdown渲染、代码高亮、相关文章
- 产品展示：产品卡片、精选展示
- 关于页面：个人介绍、技能标签、联系方式

### 后台管理
- 仪表盘：数据统计、快捷操作
- 文章管理：CRUD操作、Markdown编辑器、图片上传
- 产品管理：CRUD操作、多图上传
- 个人资料：头像上传、信息编辑
- 用户认证：登录/登出

## 技术栈

- **后端**: Node.js + Express
- **数据库**: SQLite (better-sqlite3)
- **模板引擎**: EJS
- **样式**: Tailwind CSS (CDN)
- **图标**: Lucide Icons
- **字体**: Google Fonts (Inter)

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 启动服务器

```bash
npm start
```

开发模式（自动重启）：
```bash
npm run dev
```

### 3. 访问网站

- 前台: http://localhost:3000
- 后台: http://localhost:3000/admin/login

### 默认账号
- 用户名: `admin`
- 密码: `jianbing2024`

## 项目结构

```
jianbing-fullstack/
├── server.js              # 主服务器文件
├── package.json           # 项目配置
├── data/                  # 数据库目录
│   └── database.db        # SQLite数据库
├── public/                # 静态资源
│   └── images/            # 图片目录
├── views/                 # 模板文件
│   ├── layout.ejs         # 布局模板
│   ├── index.ejs          # 首页
│   ├── articles.ejs       # 文章列表
│   ├── article-detail.ejs # 文章详情
│   ├── products.ejs       # 产品列表
│   ├── about.ejs          # 关于页面
│   ├── 404.ejs            # 404页面
│   └── admin/             # 后台模板
│       ├── login.ejs      # 登录页
│       ├── dashboard.ejs  # 仪表盘
│       ├── articles.ejs   # 文章管理
│       ├── article-edit.ejs # 文章编辑
│       ├── products.ejs   # 产品管理
│       ├── product-edit.ejs # 产品编辑
│       └── profile.ejs    # 个人资料
```

## 数据库表结构

### articles (文章表)
- id, title, slug, content, excerpt, cover_image
- category, tags, status (draft/published)
- view_count, created_at, updated_at

### products (产品表)
- id, name, slug, description, short_description
- images, tech_stack, project_url, github_url
- featured, display_order, created_at, updated_at

### admins (管理员表)
- id, username, password_hash, email, created_at, last_login

### profile (个人资料表)
- id, name, title, avatar, bio, email, phone, location
- github, twitter, linkedin, wechat, skills, updated_at

## 自定义配置

### 修改网站信息
编辑 `server.js` 中的 `app.locals`：

```javascript
app.locals.siteTitle = '煎饼 - AI行动家';
app.locals.siteDescription = '专注于AI智能体与编程业务';
```

### 修改主题颜色
编辑各模板文件中的 Tailwind 配置。

### 修改默认管理员
首次启动后，建议立即修改默认密码。

## 部署

### 部署到 Vercel

1. 安装 Vercel CLI:
```bash
npm i -g vercel
```

2. 部署:
```bash
vercel
```

### 部署到服务器

1. 上传代码到服务器
2. 安装依赖: `npm install --production`
3. 启动: `npm start`
4. 使用 PM2 守护进程:
```bash
npm install -g pm2
pm2 start server.js --name jianbing-website
```

## 注意事项

1. **安全性**: 生产环境请修改默认密码和 session secret
2. **备份**: 定期备份 `data/database.db` 文件
3. **图片**: 上传的图片保存在 `public/images/` 目录

## 许可证

MIT
